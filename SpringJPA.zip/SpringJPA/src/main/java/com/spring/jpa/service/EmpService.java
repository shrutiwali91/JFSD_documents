package com.spring.jpa.service;


import java.util.ArrayList;

import org.springframework.stereotype.Service;

import com.spring.jpa.model.Employee;

@Service
public interface EmpService {
    ArrayList<Employee> findAllEmployee();
    Employee findAllEmployeeByID(long id);
    void addEmployee();
    void deleteAllData();
}
