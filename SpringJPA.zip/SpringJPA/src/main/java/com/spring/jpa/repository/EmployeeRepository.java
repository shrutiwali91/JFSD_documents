package com.spring.jpa.repository;


import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.spring.jpa.model.Employee;


@Repository 
public interface EmployeeRepository extends CrudRepository<Employee, Long>{  
	//Optional<Employee> findAllEmployeeByID(long id);
//	List<Employee> findByEmployeeId(long id);
	
  
}



//@Repository is a Spring annotation that
//indicates that the decorated class is a repository.
