package com.spring.jpa.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

// @Entity annotation defines that a 
// class can be mapped to a table
@Table
@Entity(name ="employee")
public class Employee {
  

    @Id 
    @GeneratedValue(strategy = GenerationType.AUTO) 
    @Column(name="id")
    private long id;
    
    @Column(name="name")
    private String name;
    
    @Column(name="city")
    private String city;

    public Employee() {
        super();
    }
    public Employee(String  city, String name) {
        super();
        this.name = name;
        this.city = city;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

}

// @ID This annotation specifies 
// the primary key of the entity.