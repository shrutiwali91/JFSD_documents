package com.spring.mangodb.repository;


import org.springframework.data.mongodb.repository.MongoRepository;

import com.spring.mangodb.model.Book;
 
public interface BookRepo
    extends MongoRepository<Book, Integer> {
}