package com.spring.mangodb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

@EnableSwagger2
@EnableMongoRepositories("com.spring.*")
@EntityScan("com.spring.*") 
@SpringBootApplication(scanBasePackages = { "com.spring.*" }) 
public class MangodbApplication {

	public static void main(String[] args) {
		SpringApplication.run(MangodbApplication.class, args);
	}

}
