const express = require('express')
const { getDb, connectToDb } = require('./db')

// init app & middleware
const app = express()

// db connection
let db

connectToDb((err) => {
  if(!err){
    app.listen('3000', () => {
      console.log('app listening on port 3000')
    })
    db = getDb()
  }
})

// routes
app.get('/books', (req, res) => {
  let booksList = []

  db.collection('books')
    .find()
    .forEach(book => booksList.push(book))
    .then(() => {
      res.status(200).json(booksList)
    })
    .catch(() => {
      res.status(500).json({error: 'Could not fetch the documents'})
    })
})