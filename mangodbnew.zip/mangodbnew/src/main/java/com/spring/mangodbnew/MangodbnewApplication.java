package com.spring.mangodbnew;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MangodbnewApplication {

	public static void main(String[] args) {
		SpringApplication.run(MangodbnewApplication.class, args);
	}

}
