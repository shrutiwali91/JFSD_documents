package com.spring.mangodbnew;

//import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MangodbnewApplicationTests {

	/*@Test
	void contextLoads() {
	}*/

}
