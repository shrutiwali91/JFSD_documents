package com.testme.testme;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.spring.di.MessageSender;
import com.spring.di.MessageSender1;
import com.spring.di.MessageSender2;
import com.spring.di.MessageSender3;
import com.spring.di.MessageSender4;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.servlet.config.annotation.EnableWebMvc; 

@EnableSwagger2
@SpringBootApplication(scanBasePackages = { "com" })
public class TestmeApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestmeApplication.class, args);
		/*String message = "Hi, good morning have a nice day!.";
        ApplicationContext applicationContext = new AnnotationConfigApplicationContext(TestmeApplication.class);
        MessageSender messageSender = applicationContext.getBean(MessageSender.class);
        messageSender.sendMessage(message);*/
        
        
        
        
        
        
      // MessageSender1 messageSender1 = applicationContext.getBean(MessageSender1.class);
        //MessageSender2 messageSender2 = applicationContext.getBean(MessageSender2.class);
        //MessageSender3 messageSender3 = applicationContext.getBean(MessageSender3.class);
        //MessageSender4 messageSender4 = applicationContext.getBean(MessageSender4.class);
        
       
        //messageSender1.sendMessage(message);
        //messageSender2.sendMessage(message);
        //messageSender3.sendMessage(message);
        //messageSender4.sendMessage(message);
	}

}
