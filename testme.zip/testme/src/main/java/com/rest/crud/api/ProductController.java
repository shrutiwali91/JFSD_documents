package com.rest.crud.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/products")
public class ProductController {

	
	/*
	 * below  are the URLs to call the REST API
	 * 1. Get All Products : GET:http://localhost:8095/testmeservice/api/v1/products
	 * 2. Get Single Products : GET: http://localhost:8095/testmeservice/api/v1/products/1
	 * 3. Create Product:POST :http://localhost:8095/testmeservice/api/v1/products : In body : raw add the JSON data {"id":1, "name":"myProduct", "quantity":10,"price":100} 
	 * 4. Update the Product : PUT : http://localhost:8095/testmeservice/api/v1/products  : In body : raw add the JSON data {"id":1, "name":"myProduct is updated", "quantity":10,"price":100} 
	 * 5. Delete Product : DELETE : http://localhost:8095/testmeservice/api/v1/products/1
	  */
    @Autowired
    private ProductService service;

    @PostMapping
    public Product addProduct(@RequestBody Product product) {
        return service.saveProduct(product);
    }

    @GetMapping
    public List<Product> findAllProducts() {
        return service.getProducts();
    }

    @GetMapping("{id}")
    public Product findProductById(@PathVariable int id) {
        return service.getProductById(id);
    }

    @PutMapping
    public Product updateProduct(@RequestBody Product product) {
        return service.updateProduct(product);
    }

    @DeleteMapping("{id}")
    public String deleteProduct(@PathVariable int id) {
        return service.deleteProduct(id);
    }
}
