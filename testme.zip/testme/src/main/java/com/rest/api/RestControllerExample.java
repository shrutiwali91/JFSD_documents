package com.rest.api;

import java.util.concurrent.atomic.AtomicLong;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController // @controller 
public class RestControllerExample {

		// GET method
		@GetMapping("/")
		public String home(){
			String str
				= "<html><body><font color=\"green\">"
				+ "<h3>WELCOME To JAVA Class to sessios </h3>"
				+ "</font></body></html>";
			return str;
		}

		// Another syntax to implement a
		// GET method
		@RequestMapping(method = { RequestMethod.GET },value = { "/gfg" })
		public String info()
		{
			String str2
				= "<html><body><font color=\"green\">"
				+ "<h2>Java is a high-level, class-based, object-oriented programming language that is designed"
				+ " to have as few implementation dependencies as possible."
				+ "</h2></font></body></html>";
			return str2;
		}
		
		/*private static final String template = "Hello, %s!";
		private final AtomicLong counter = new AtomicLong();

		@GetMapping("/greeting")
		public Greeting greeting(@RequestParam(value = "name", defaultValue = "World") String name) {
			return new Greeting(counter.incrementAndGet(), String.format(template, name));
		}*/
}
