package com.spring.di;

public interface MessageService {

	void sendMessage(String message);
}
