package com.spring.di;

public class MessageSender3 {

}
