// Creating an Empty Array
let names = [];
const studetNames = [];

console.log(names);

// Creating an Array and Initializing with Values
let courses = [ "HTML", "CSS", "Javascript", "React" ];

console.log(courses);
//*************************************************************************
//Creating an Array using Array Constructor (JavaScript new Keyword)
//Declaration of an empty array 
//using Array constructor
let names1 = new Array();
console.log(names1);

//Creating and Initializing an array with values
let courses1 = new Array("HTML", "CSS", "Javascript", "React");
console.log(courses1);

//Initializing Array while declaring
let arr = new Array(3);
arr[0] = 10;
arr[1] = 20;
arr[2] = 30;
console.log(arr);

//**************************************************************************************
//1. Accessing Elements of an Array
//Creating an Array and Initializing with Values
let courses2 = [ "HTML", "CSS", "Javascript", "React" ];

// Accessing Array Elements
console.log(courses2[0]);
console.log(courses2[1]);
console.log(courses2[2]);
console.log(courses2[3]);
//***********************************************************************************
//Accessing the First Element of an Array
//Creating an Array and Initializing with Values
let courses3 = [ "HTML", "CSS", "JavaScript", "React" ];

// Accessing First Array Elements
let firstItem = courses3[0];

console.log("First Item: ", firstItem);
//****************************************************************************
//Accessing the Last Element of an Array
//Creating an Array and Initializing with Values
let courses4 = [ "HTML", "CSS", "JavaScript", "React" ];

// Accessing Last Array Elements
let lastItem = courses4[courses4.length - 1];

console.log("First Item: ", lastItem);

//*******************************************************************************
//Modifying the Array Elements
//Creating an Array and Initializing with Values
let courses5 = [ "HTML", "CSS", "Javascript", "React" ];
console.log(courses5);

courses5[1] = "Bootstrap";
console.log(courses5);
//*********************************************************************************
//Adding Elements to the Array
//Creating an Array and Initializing with Values
let courses6 = [ "HTML", "CSS", "Javascript", "React" ];

// Add Element to the end of Array
courses6.push("Node.js");

// Add Element to the beginning
courses6.unshift("Web Development");

console.log(courses6);
//*******************************************************************************
//Removing Elements from an Array
//Creating an Array and Initializing with Values
let courses7 = [ "HTML", "CSS", "Javascript", "React", "Node.js" ];
console.log("Original Array: " + courses7);

// Removes and returns the last element
let lastElement = courses7.pop();
console.log("After Removed the last elements: " + courses7);

// Removes and returns the first element
let firstElement = courses7.shift();
console.log("After Removed the First elements: " + courses7);

// Removes 2 elements starting from index 1
console.log("before splice elements: " + courses7);
courses7.splice(0, 2);
console.log("After Removed 2 elements starting from index 1: " + courses7);

//**************************************************************************************
// Array Length
//Creating an Array and Initializing with Values
let courses8 = [ "HTML", "CSS", "Javascript", "React", "Node.js" ];

let len = courses8.length;

console.log("Array Length: " + len);

//************************************************************************************
//Increase and Decrease the Array Length
//Creating an Array and Initializing with Values
let courses9 = [ "HTML", "CSS", "Javascript", "React", "Node.js" ];

// Increase the array length to 7
courses9.length = 7;

console.log("Array After Increase the Lengt :::::h: ", courses9);

// Decrease the array length to 2
courses9.length = 2;
console.log("Array After Decrease the Length: ", courses9)

//***************************************************************************
// Iterating Through Array Elements
// Creating an Array and Initializing with Values
let courses10 = [ "HTML", "CSS", "JavaScript", "React" ];

// Iterating through for loop
for (let i = 0; i < courses10.length; i++) {
	console.log(courses10[i])// courses[0]
}

console.log("for each loop------------", courses10)
//Iterating through forEach loop
courses10.forEach(function loopstame(elements) { // courses[0] , courses[1]
	console.log(elements);
});
//---------------------------------------------------
console.log("While------------", courses10)
let n = 0;
while (n < courses10.length) {
	
	console.log(courses10[n])
	n++;
}
//---------------------------------------------------
console.log(" do While------------", courses10)
let x = 0;
do {
	console.log(courses10[x])
	x++;

} while (x < courses10.length)

//*************************************************************************
// Array Concatenation
//Creating an Array and Initializing with Values
let courses11 = [ "HTML", "CSS", "JavaScript", "React" ];
let otherCourses = [ "Node.js", "Expess.js" ];

// Concatenate both arrays
let concateArray = courses11.concat(otherCourses);

console.log("Concatenated Array: ", concateArray);
//*************************************************************************
//Conversion of an Array to String

//Creating an Array and Initializing with Values
let courses12 = [ "HTML", "CSS", "JavaScript", "React" ];

// Convert array ot String
console.log(courses12.toString());
