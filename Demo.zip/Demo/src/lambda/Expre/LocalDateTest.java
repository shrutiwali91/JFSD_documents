package lambda.Expre;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
public class LocalDateTest {

	public static void main(String[] args)
    {
        // now() is a method to return the
        // instance of LocalDateTime class.
		Date d = new Date();
		System.out.println(d);
		
        LocalDateTime localDate = LocalDateTime.now();
        DateTimeFormatter dateformatter
            = DateTimeFormatter.ofPattern("MM dd, YYYY");
        // display the date
        System.out.println(dateformatter.format(localDate));
        
     // Parses the date
        LocalDate dt1 = LocalDate.parse("2021-01-07");
        LocalDate result = dt1.withDayOfYear(01);
 
        // Prints the date with year
        System.out.println("The date with day of year is: "
                           + result);
    }
}
