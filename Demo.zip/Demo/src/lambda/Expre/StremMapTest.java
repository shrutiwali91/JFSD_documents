package lambda.Expre;

import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StremMapTest {

	public static void main(String[] args) {
		//Processing Maps with Streams:
		
		// 1.Filtering and Collecting Map Entries
		Map<String, Integer> employeeSalaries = new HashMap<>();
		employeeSalaries.put("Alice", 5000);
		employeeSalaries.put("Bob", 7000);
		employeeSalaries.put("Charlie", 4000);
		employeeSalaries.put("Dave", 6000);

		int salaryThreshold = 5000;

		List<String> highPaidEmployees = employeeSalaries.entrySet().stream()
		    .filter(entry -> entry.getValue() > salaryThreshold)
		    .map(Map.Entry::getKey)
		    .collect(Collectors.toList());
		System.out.println(highPaidEmployees);

		// Output: [Alice, Bob, Dave]

		//2.Summing Map Values
		Map<String, Integer> scores = new HashMap<>();
		scores.put("Alice", 90); 
		scores.put("Bob", 80); 
		scores.put("Charlie", 95);  

		//getKeySet , getValue
		int totalScore = scores.values().stream().reduce(0, Integer::sum); 

		System.out.println(totalScore); // Output: 265
		
		//3. Merging Maps
		Map<String, Integer> document1 = new HashMap<>();
		document1.put("apple", 3);
		document1.put("banana", 2);
		document1.put("cherry", 1);

		Map<String, Integer> document2 = new HashMap<>();
		document2.put("banana", 4);
		document2.put("date", 2);
		document2.put("elderberry", 5);

		Map<String, Integer> mergedMap = Stream.of(document1, document2)
		    .flatMap(map -> map.entrySet().stream()) // apple :1, banna: 2 + 4 = 6, Cheery: 1
		    .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, Integer::sum));

		System.out.println(mergedMap);
		// Output: {apple=3, banana=6, cherry=1, date=2, elderberry=5}
		
		//4.Sorting Map by Values
		Map<String, Integer> studentScores = new HashMap<>();
		studentScores.put("Alice", 85);
		studentScores.put("Bob", 92);
		studentScores.put("Charlie", 78);
		studentScores.put("Dave", 91);

		List<Map.Entry<String, Integer>> sortedEntries = studentScores.entrySet().stream()
		    .sorted(Map.Entry.comparingByValue(Comparator.reverseOrder()))
		    .collect(Collectors.toList());

		System.out.println(sortedEntries);
		// Output: [Bob=92, Dave=91, Alice=85, Charlie=78]
	}
}
