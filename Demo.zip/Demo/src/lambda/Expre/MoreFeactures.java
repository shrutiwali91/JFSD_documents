package lambda.Expre;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class MoreFeactures {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Stream API:
		List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5);
		Optional<Integer> firstEven = numbers.stream()
		.filter(x -> x % 2 == 0)
		.findFirst();
		System.out.println(firstEven.get()); // prints 2
		
		
		//method reference 
		List<String> strings = Arrays.asList("a", "b", "c", "d");
		// Use a lambda expression to print all elements in the list
		strings.forEach(s -> System.out.println(s));
		// Use a method reference to print all elements in the list
		strings.forEach(System.out::println);
		}

	}


