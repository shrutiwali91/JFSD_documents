package lambda.Expre;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;


public class Main {

	public static void main (String[] args) {
		
	    // example of a Function
	    Function<Integer, Integer> plusOne = new PlusOne();
	    Integer result1 = plusOne.apply (4);
	    System.out.println("result: " + result1);
	   // example of a Predicate, i.e, a Function that return a boolean
	    Predicate areHappy = new AreHappy();
	    boolean result2 = areHappy.test("hello");
	    System.out.println("result: " + result2);	
	    
	    // our AreHappy Predicate (Function that return boolen)
	    Predicate predicate = (value) -> value != null;
	 // our MyComparator Function
	    List<String> ar = new ArrayList<>();
	    ar.add("abcc");
	    ar.add("java");
	    ar.add("function");
	    ar.add("lambda");
	  //  Collections.sort(ar);
	    
	    // void(a, b){
	    //}
	    
	    Collections.sort(ar, (a, b) -> {
	      if (a.length() == b.length()) return 0;
	      else if (a.length() < b.length()) return -1;
	      return 1;
	    });
	    System.out.println(ar);
	  }
}
