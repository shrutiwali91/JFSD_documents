package lambda.Expre;

import java.util.function.Predicate;

public class AreHappy implements Predicate {
  @Override
  public boolean test(Object o) {
    System.out.println(o);
    return o  != null;
  }
}
