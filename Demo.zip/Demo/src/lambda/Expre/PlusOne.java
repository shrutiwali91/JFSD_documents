package lambda.Expre;

import java.util.function.Function;

public class PlusOne implements Function <Integer, Integer> {
  @Override
  public Integer apply(Integer value) {
    //your code here
    return value + 10;
  }
}
