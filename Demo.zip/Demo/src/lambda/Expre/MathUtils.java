package lambda.Expre;

public class MathUtils {

	 public static int multiply(int a, int b) {
	        return a * b;
	    }
}
