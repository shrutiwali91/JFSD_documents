package lambda.Expre;

import java.util.function.BiFunction;
import java.util.function.IntBinaryOperator;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class MethodReferenceTest {

	public static void main(String[] args) {
		//Reference to a static method
		//MathUtils.multiply(10, 20);
        IntBinaryOperator operator = MathUtils::multiply;
        int result = operator.applyAsInt(4, 5);
        System.out.println(result);
        
        //Reference to an instance method of an object
        Person person = new Person("John");
        Supplier<String> supplier = person::getName;
        String name = supplier.get();
        System.out.println(name);
        
      //Reference to a constructor:
        BiFunction<String, Integer, Person> personConstructor = Person::new;
        Person person1 = personConstructor.apply("John", 25);
        System.out.println(person1.getName());
        System.out.println(person1.getAge());
        
        //Reference to an instance method of an arbitrary object of a particular
       /* Predicate<String> predicate = StringUtilsEx :: startsWithUppercase;
        boolean result1 = predicate.test("Hello");
        System.out.println(result1);*/
    }
}

