package lambda.Expre;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class StreamListTest {

	public static void main(String[] args) {
		//Processing Lists with Streams:
		
		//1. Filtering and Mapping
		List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5); 
		List<Integer> squares = numbers.stream().filter(n -> n % 2 == 0)
		                         .map(n -> n * n).collect(Collectors.toList()); // 4, 16

		System.out.println(squares); // Output: [4, 16]
		
		
		//2. Summing Integers
		List<Integer> numbers1 = Arrays.asList(1, 2, 3, 4, 5); 
		int sum = numbers1.stream().reduce(0, Integer::sum);

		System.out.println(sum); // Output: 15
		
		 //3. Grouping and Summing Elements
	
		
		List<Transaction> transactions = Arrays.asList(
			    new Transaction("Grocery", 50.0),
			    new Transaction("Grocery", 30.0),
			    new Transaction("Shopping", 100.0),
			    new Transaction("Shopping", 150.0),
			    new Transaction("Grocery", 20.0)
			    
			);

		//Groc , (50.0+30.0+ 20+0 )  == Grocery : 100.0
		//Shopping ,(100.0 + 150.0 ==  Shopping : 250
			Map<String, Double> totalAmountByType = transactions.stream()
			    .collect(Collectors.groupingBy(Transaction::getType, Collectors.summingDouble(Transaction::getAmount)));

			System.out.println(totalAmountByType);
			// Output: {Grocery=100.0, Shopping=250.0}

			
		//4. FlatMapping and Distinct Elements
			//Problem : Suppose you have a list of books, and each book has a list of authors.
			//You want to get a list of all unique authors from the books.
			// 1 -- N  (tittle(java) -- Authors (Arun, Ash, Hr)) , ( Python -- Arun, Jothi) , 3 - html: Karthik, Har
			
			List<Book> books = Arrays.asList(
				    new Book("Book 1", Arrays.asList("Arun", "Ashok" ,"Harishta")),
				    new Book("Book 2", Arrays.asList("Arun", "Joythi")),
				    new Book("Book 3", Arrays.asList("Karthik", "Harishta"))
				);

				List<String> uniqueAuthors = books.stream()
				    .flatMap(book -> book.getAuthors().stream())
				    .distinct()
				    .collect(Collectors.toList());

				System.out.println(uniqueAuthors);
				// Output: [Author 1, Author 2, Author 3]
		
				//5. Partitioning Elements
				List<Integer> numbers11 = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);

				Map<Boolean, List<Integer>> oddAndEvenNumbers = numbers11.stream()
				    .collect(Collectors.partitioningBy(n -> n % 2 == 0));

				System.out.println(oddAndEvenNumbers);
				// Output: {false=[1, 3, 5, 7, 9], true=[2, 4, 6, 8, 10]}
			
				 
	}
}
