package lambda.Expre;

public class StringUtilsEx {

	 public boolean startsWithUppercase(String s) {
	        return Character.isUpperCase(s.charAt(0));
	    }
}
