package lambda.Expre;

import java.util.ArrayList;

interface calculate {

	public void print();	
}

interface calculateSum {
	int sum(int n1,int n2,int n3);	
}

interface calculateadd {
	int add(int n1,int n2);	
}
public class LambdaExpressionTest {
	//public void print(){
	//Ssyem.out.print("Hello");
	//}

	public static void main(String[] args) {
		
		//(parameters inside parenthesis) -> {body inside curly brackets}
		int a=12;
		//With the use of the lambda expression in java we are implementing
		calculate c=()->{
		System.out.println("The result of the following expression is "+a);
		};
		
		c.print();
	
		// Example of the Lambda expression without using the return keyword.
		
		calculateSum c1=(n1,n2,n3)->(n1+n2+n3);
		System.out.println(c1.sum(13,23,45));
		
		// Example of the Lambda expression with and using the return keyword.
		calculateadd c2=(int n1,int n2)->{
			return (n1*n2);
			};
		System.out.println(c2.add(14,230));

		//Second Sceanrio
		ArrayList<Integer> arr = new ArrayList<Integer>();
		arr.add(12);
		arr.add(93);
		arr.add(84);
		arr.add(67);
		arr.add(65);
		arr.add(9);
		arr.add(42);
		arr.add(23);
		arr.forEach( (n) -> { System.out.println(n); } );
		
		//for(Inter a : arr){
		//System.out.println("A value"+a);
		//}
		
		
		
	}

}
