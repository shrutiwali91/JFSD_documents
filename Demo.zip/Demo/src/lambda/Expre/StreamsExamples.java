package lambda.Expre;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class StreamsExamples {
  public static void main(String[] args) throws IOException {
    // stream of elements
    Stream<String> streamOfArray = Stream.of ("alpha", "beta", "delta");
    // stream from a builder
    Stream<String> streamBuilder = Stream.<String>builder()
      .add("alpha")
      .add("beta")
      .add("delta")
      .build();
    // stream from a collection
    List<String> ar = new ArrayList<>();
    Stream<String> streamfromCollection = ar.stream();
    
    
    // map operation
    Stream<String> result = streamOfArray
      .map(element -> element.substring(0, 3));
    // stream pipeline map + sort
    result = streamOfArray
      .map(element -> element.substring(0, 3))
      .sorted();
    // reduce a stream of numbers to a single number
    int reducedResult = Stream.of (1, 2, 3)
      .reduce(10, (a, b) -> { return a + b;}
      );
    // parallel streams
    List<Integer> grades = new ArrayList<>();
    grades.add(95); grades.add(65); grades.add(30);
    boolean someoneFail = grades.parallelStream()
      .map( grade-> grade + 5)
      .anyMatch(variable -> variable < 65);
  }
}
