package collection.demo;

import java.util.ArrayList;
import java.util.Stack;

public class StackDemo {

	public static void main(String[] args)
    {
 
        // Creating an empty Stack (LIFO -  
        Stack<String> STACK = new Stack<String>();
 
        // Stacking strings
        STACK.push("Welcome");
        STACK.push("Main");
        STACK.push("boot");
        STACK.push("camp");
        STACK.push("JAVA");
       
 
        // Displaying the Stack
        System.out.println("The stack is: " + STACK);
 
        // Checking for the emptiness of stack
        System.out.println("Is the stack empty? " +
                                    STACK.empty());
 
        // Popping out all the elements
        STACK.pop();
        STACK.pop();
        STACK.pop();
        STACK.pop();
        STACK.pop();
 
        // Checking for the emptiness of stack
        System.out.println("Is the stack empty? " +
                                    STACK.empty());
        
        // Checking for the element "JAVA" 
        System.out.println("Does the stack contains 'JAVA'? "
                                     + STACK.search("JAVA")); 
        
     // Removing elements using pop() method
        System.out.println("Popped element: " + 
                                         STACK.pop());
    }
}
