package collection.demo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.TreeSet;

public class HashSetDemo {

	public static void main(String[] args) {
		// your code goes here
		HashSet<String> h = new HashSet<String>();

		// Adding elements into HashSet using add()
		h.add("Welcome");
		h.add("Main");
		h.add("boot");
		h.add("java");

		// Iterating over hash set items
		for (String i : h) {
			System.out.println(i);
		}
		// Iterating over HashSet elements
		// using iterator
		/*Iterator<String> i = h.iterator();

		// Holds true till there is single element remaining in the Set
		while (i.hasNext()) {
			// Printing the elements
			System.out.println(i.next());
		}*/

		// Sorting ways
		// Sorting HashSet using List
		
		List<String> list = new ArrayList<String>(h);
		Collections.sort(list);

		System.out.println(h.isEmpty());
		// Sorting HashSet using TreeSet
		TreeSet<String> treeSet = new TreeSet<String>(h);

		System.out.println(h.contains("java"));
		// Print Maximum value using max method of
		// Collections class
		System.out.println("Maximum value of HashSet : " + Collections.max(h));

		// Print Maximum value using max method of
		// Collections class
		System.out.println("Minimum value of HashSet : " + Collections.min(h));
	}
}
