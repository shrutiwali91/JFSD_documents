package collection.demo;

import java.util.ArrayList;

public class ArrayListDemo {

	public static void main(String[] args) 
    { 
  
        ArrayList<Integer> arrlist = new ArrayList<Integer>(5); 
  
        // add elements in the list 
        arrlist.add(4); 
        arrlist.add(10); 
        arrlist.add(2); 
        arrlist.add(8); 
        arrlist.add(299); 
  
        // prints all the elements available in list 
        for (Integer number : arrlist) { 
            System.out.println("Number = " + number); 
        } 
        //This makes a call to remove(int) and 
        arrlist.remove(1); 
        
        int i = arrlist.set(2, 30); 
        
        // Print the modified arrlist 
        System.out.println("After updating: "
                           + arrlist); 
         
         
    } 
}
