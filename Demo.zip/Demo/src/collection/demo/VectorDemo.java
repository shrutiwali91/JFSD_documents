package collection.demo;

import java.util.Vector;

public class VectorDemo {

	public static void main(String args[]) {
		// Creating an empty Vector
		Vector<String> vt = new Vector<String>();

		// Use add() method to add elements into the Vector
		vt.add("Welcome");
		vt.add("To");
		vt.add("JAVA");
		vt.add("Class");
		vt.add("11");

		// Displaying the Vector
		System.out.println("Vector: " + vt);

		// Using set() method to replace Geeks with GFG
		System.out.println("The Object that is replaced is: " + vt.set(2, "GFG"));

		// Clearing the Vector using clear() method
		vt.clear();

		// Displaying the final vector after clearing;
		System.out.println("The final Vector: " + vt);

		// Verifying if the Vector is empty or not
		System.out.println("Is the Vector empty? " + vt.isEmpty());
	}
}
