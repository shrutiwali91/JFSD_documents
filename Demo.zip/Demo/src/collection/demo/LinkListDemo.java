package collection.demo;

import java.util.LinkedList;
import java.util.List;

public class LinkListDemo {

	public static void main(String args[]) { 
		  
	      // Creating an empty LinkedList  //O(n), log(n) //Sonar List : 1. ArrayList, 2 lineked List
		LinkedList<String> list = new LinkedList<String>(); 
	  
	      // Use add() method to add elements in the list 
	      list.add("demo"); 
	      list.add("on"); 
	      list.add("java"); 
	      list.add("main"); 
	      list.add("20"); 
	  
	      // Displaying the list 
	      System.out.println("LinkedList:" + list); 
	        
	      // Fetching the specific element from the list 
	      System.out.println("The element is: " + list.get(2)); 
	      
	      // Check if the list contains "demo"
	      System.out.println("\nDoes the List contains 'demo': "
	                                      + list.contains("demo"));
	  
	   } 
	
}
