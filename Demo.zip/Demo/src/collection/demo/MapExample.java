package collection.demo;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

public class MapExample {

	//Hash Map -- One nUll Key --
	//Tree Map -- DOes null Key -- Sorted
	public static void main(String[] args) {
		// Map == HashMap, LinkedHashMap, TreeMap(SortedMap -- Sorted Asc)
		HashMap<Integer, String> hashMap = new HashMap<>();
//Float ,//Double
		//int a = null;
		Integer a = null;
		System.out.println(a);
		System.out.println();
		//6 : Arun , Asghok, Swa -- , 3 --Shru, 1 -- Sange
		hashMap.put(8, "Arun"); 
		hashMap.put(10, "Ashok");
		hashMap.put(3, "Shruti");
		hashMap.put(1, "Sangeeta");
		hashMap.put(6, "Swathi");
		hashMap.put(3, "Java");
		hashMap.put(2, null);
		hashMap.put(14, null);

		// Iterating over HashSet elements
		// using iterator
		for (Entry<Integer, String> entry : hashMap.entrySet()) {
			System.out.println(entry.getKey());
			System.out.println(entry.getValue());
		}
		
		/*for(Integer myKey : hashMap.keySet()) {
			System.out.println("Key ::"+myKey);
		}
		
		for(String myValue : hashMap.values()) {
			System.out.println("Value ::"+myValue);
		}
*/
		System.out.println("***************************************");
		
		Iterator<Entry<Integer, String>> i = hashMap.entrySet().iterator();

		// Holds true till there is single element remaining in the Set
		while (i.hasNext()) {
			// Printing the elements
			Map.Entry<Integer, String> entry =i.next();
			System.out.println(entry.getKey());
			System.out.println(entry.getValue());
			
		}
	}

}
