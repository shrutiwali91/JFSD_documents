package collection;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class EmployeeSortingExample {

	public static void main(String[] args) {
        List<Employee> employees = new ArrayList<>();
        employees.add(new Employee(10, "Shruti", 25, 10000));
        employees.add(new Employee(20, "Arun", 29, 20000));
        employees.add(new Employee(5, "Arun", 35, 30000));
        employees.add(new Employee(2, "Sangeta", 30, 5000));

        // Sort the list of employees (natural ordering by ID)
        //Collectuons.Sort(setobj);
        Collections.sort(employees);

        // Display the sorted list
        for (Employee employee : employees) {
            System.out.println(employee);
        }
        
        System.out.println("______________________________________");
      //sort employees array using Comparator by Salary
        System.out.println("**********Sort by salary****************");
        Collections.sort(employees, EmployeeComparator.SalaryComparator);
        // Display the sorted list
        for (Employee employee : employees) {
            System.out.println(employee);
        }
      System.out.println("**********Sort by age***************");
        //sort employees array using Comparator by Age
        Collections.sort(employees, Employee.AgeComparator);
        // Display the sorted list
        for (Employee employee : employees) {
            System.out.println(employee);
        }
            //sort employees array using Comparator by Name
        System.out.println("**********Sort by Name***************");
        EmployeeComparator empComp = new EmployeeComparator();
        Collections.sort(employees, empComp);
        // Display the sorted list
        for (Employee employee : employees) {
            System.out.println(employee);
        }
    }
}
