package collection;

import java.util.Comparator;

public class EmployeeComparator implements Comparator<Employee> {
	
	
	/*
    * Comparator to sort employees list or array in order of Salary
    */
   public static Comparator<Employee> SalaryComparator = new Comparator<Employee>() {

       @Override
       public int compare(Employee e1, Employee e2) {
           return (int) (e1.getSalary() - e2.getSalary());
       }
   };

  
    @Override
    public int compare(Employee employee1, Employee employee2) {
        return employee1.getName().compareTo(employee2.getName());
    }
    
    
    
}