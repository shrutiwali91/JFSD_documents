
public class MemoryMang {

	public void finalize() {
		System.out.println("object is garbage collected");
	}

	public static void main(String args[]) throws CloneNotSupportedException {
		MemoryMang s1 = new MemoryMang();
		MemoryMang s2 = new MemoryMang();
		s2 = s1;
		s2 = (MemoryMang) s1.clone();
		//S2 add -- Copy s1 -- 
		s1 = null;
		s2 = null;
		System.gc();
		
		
		
		
	}
}
