package Test;

import demo.MyDemo;

public class Test{

	int myCount = 1000;
	public static void main(String[] args) {
		
		/*MyDemo dd = new MyDemo();
		System.out.println(dd.x);
		
		System.out.println(dd.sum(100, 400));
		*/
		
	}

}
