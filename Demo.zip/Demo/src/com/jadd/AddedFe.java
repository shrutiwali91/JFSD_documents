package com.jadd;

import java.util.Arrays;
import java.util.List;
import java.util.Set;

public class AddedFe {

	public static void main(String[] args) {
		
		List ll = Arrays.asList(1, 2, 3); // priori java 9
		List list = List.of(1, 2, 3, 4); //
        System.out.println(list); // [1, 2, 3, 4]
        
        Set<String> strKeySet = Set.of("key1", "key2", "key3");
        
	}

}
