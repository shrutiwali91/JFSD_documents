package com.myfile;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class FileManagement {

	
	
	public static void main(String[] args)
    {
//		try {
//		File ob = new File("C:\\RPA\\Test.txt");
//		ob.createNewFile(); //Unhandled exception type IOException
//		}catch (Exception e) {
//			// TODO: handle exception
//		}
    /*   try {
            File Obj = new File("Test.txt");
            if (Obj.createNewFile()) {
                System.out.println("File created: "
                                   + Obj.getName());
                
               
            }
            else {
                System.out.println("File already exists.");
            }
            Obj.delete();
            
            if (Obj.exists()) {
                System.out.println("file exist ");
                                            
            }else {
            	 System.out.println("file deleted/does not exist  ");
            }
        }
        catch (IOException e) {
            System.out.println("An error has occurred.");
            e.printStackTrace();
        }
      //Write to File
        try {
            FileWriter Writer
                = new FileWriter("myfile.txt"); // Create , Opens, Write, Close
            Writer.append("FFFFF");
            
     
            
            
            Writer.close();
            System.out.println("Successfully written.");
        }
        catch (IOException e) {
            System.out.println("An error has occurred.");
            e.printStackTrace();
        }*/
        
        //Read from a File
        try {
            File Obj = new File("myfile.txt");
            FileWriter Writer1
            = new FileWriter("myfileTemp.txt");
            Scanner Reader = new Scanner(Obj);
            while (Reader.hasNextLine()) {
                String data = Reader.nextLine();
                System.out.println(data);
                if(data.equalsIgnoreCase("Java")) {                       	 
                	 Writer1.write("new value");       	 
                }else {
                	 Writer1.write(data);
                }
            }
            Reader.close();
            Writer1.close();
          
            
            
        }
        catch (Exception e) {
            System.out.println("An error has occurred.");
            e.printStackTrace();
        }
        
        
        //Delete File
     /*   File Obj = new File("myfile.txt");
        if (Obj.delete()) {
            System.out.println("The deleted file is : "
                               + Obj.getName());
        }
        else {
            System.out.println(
                "Failed in deleting the file.");
        }*/
    }
}
