package com.latest.feat;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.List;

public class PrivateInterfaceMethods implements NamesInterface {
	public static void main(String[] args) {
		PrivateInterfaceMethods names = new PrivateInterfaceMethods();
        names.bar();
        names.fetchInitialData();
    }
}