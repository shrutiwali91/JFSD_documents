package com.latest.feat;

public class Person {

	String name;
	 String lastname;
	 
	
	public Person(String name) {
		this.name = name;
	}

	


	public Person(String name, String lastname) {
		super();
		this.name = name;
		this.lastname = lastname;
	}




	public String getLastname() {
		return lastname;
	}




	public void setLastname(String lastname) {
		this.lastname = lastname;
	}




	public void setName(String name) {
		this.name = name;
	}


	
	public String getName() {
		return name;
	}

}
