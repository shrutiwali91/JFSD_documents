package com.latest.feat;

import java.time.Month;

public class SwitchExpression {

	private static final Month MARCH = Month.MARCH;
	private static final  Month MAY = Month.MAY;
	private static final  Month JULY = Month.JULY;
	private static final  Month AUGUST = Month.AUGUST;
	private static final  Month OCTOBER = Month.OCTOBER;
	private static final Month DECEMBER = Month.DECEMBER;
	private static final Month JANUARY = Month.JANUARY;

	public static void main(String[] args) {
        int days = 0;
        Month month = Month.APRIL;

        switch (month) {
            case (JANUARY, MARCH, MAY, JULY, AUGUST, OCTOBER, DECEMBER ):
                days = 31;
                break;
            case FEBRUARY :
                days = 28;
                break;
            case APRIL, JUNE, SEPTEMBER, NOVEMBER :
                days = 30;
                break;
            default:
                throw new IllegalStateException();
        }
        
        // 
        int days1 = 0;
        Month month1 = Month.APRIL;

        days = switch (month) {
            case JANUARY, MARCH, MAY, JULY, AUGUST, OCTOBER, DECEMBER -> 31;
            case FEBRUARY -> 28;
            case APRIL, JUNE, SEPTEMBER, NOVEMBER -> 30;
            default -> throw new IllegalStateException();
        };
    }
	
	 private static String getTextMultipleLabels(int number) {
	        String result = "";
	        switch (number) {
	            case 1, 2:
	                result = "one or two";
	                break;
	            case 3:
	                result = "three";
	                break;
	            case 4, 5, 6:
	                result = "four or five or six";
	                break;
	            default:
	                result = "unknown";
	        };
	        return result;
	    }
}
