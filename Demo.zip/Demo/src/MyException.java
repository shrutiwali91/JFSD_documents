
public class MyException extends Exception {

	MyException() {
		System.out.println("Some Issue occured ! Please try after sometime");
	}
}
