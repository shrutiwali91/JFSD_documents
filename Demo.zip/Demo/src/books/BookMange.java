package books;

public class BookMange {

	public static void main(String[] args) {

		Library library = new Library();
		Book book1 = new Book(1,"Adventures of Tom Sawyer", "Mark Twain");
	    Book book2 = new Book(2,"Ben Hur", "Lewis Wallace");
	    Book book3 = new Book(3,"Time Machine", "H.G. Wells");
	    Book book4 = new Book(4,"Anna Karenina", "Leo Tolstoy");

	    library.addBook(book1);
	    library.addBook(book2);
	    library.addBook(book3);
	    library.addBook(book4);

	    System.out.println("Books in the library:");
	    for (Book book: library.getBooks()) {
	      System.out.println(book.GetBookName() + " by " + book.GetAuthor());
	    }

	    library.removeBook(book2);
	    System.out.println("\nBooks in the library after removing " + book2.GetBookName() + ":");
	    for (Book book: library.getBooks()) {
	      System.out.println(book.GetBookName() + " by " + book.GetAuthor());
	    }
	  }

	}

