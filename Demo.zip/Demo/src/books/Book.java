package books;

public class Book {
	private int id;
	private String Name;
	private String Author;
	private boolean IsAvailable;

	public Book(int id, String Name, String Author) {
		this.id = id;
		this.Name = Name;
		this.Author = Author;
		this.IsAvailable = true;
	}

	public int GetBookId() {
		return id;
	}

	public void SetBookId(int id) {
		this.id = id;
	}

	public String GetBookName() {
		return Name;
	}

	public void SetBookName(String Name) {
		this.Name = Name;
	}

	public String GetAuthor() {
		return Author;
	}

	public void SetAuthor(String Author) {
		this.Author = Author;
	}

	public void SetAvailability() {
		this.IsAvailable = false;
	}

	
}