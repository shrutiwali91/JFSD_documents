function myFunction(s1, s2) {
    return s1 / s2;
}
const value = myFunction(8, 2); // Calling the function
console.log(value);

//With parms
function calcAddition(number1, number2) { 
    return number1 + number2; 
}
console.log(calcAddition(6,9));

//Function Expression:
const square = function (number) {
    return number * number;
};
const x = square(4); // x gets the value 16
console.log(x);

//Functions as Variable Values
//Function to convert Fahrenheit to Celsius
function toCelsius(fahrenheit) {
    return (fahrenheit - 32) * 5/9;
  }
  
  // Using the function to convert temperature
  let temperatureInFahrenheit = 77;
  let temperatureInCelsius = toCelsius(temperatureInFahrenheit);
  console.log(temperatureInCelsius);
  let text = "The temperature is " + temperatureInCelsius + " Celsius";
  console.log(text);