package oop.inter;

public class Triangle implements Shape{

	private double height;
    private double breadth;
    
    public Triangle(double height, double breadth) {
        this.height = height;
        this.breadth = breadth;
    }
    
    public double getArea() {
        return 0.5 * height * breadth;
    }
    
    public double getPerimeter() {
        return height + breadth;
    }
    
}
