package oop.inter;

public interface Calculator {

	public int calculate(int a, int b);
	
}
