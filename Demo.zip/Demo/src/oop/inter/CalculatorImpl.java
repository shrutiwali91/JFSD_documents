package oop.inter;

public class CalculatorImpl {

	public static void main(String[] args) {
		 Calculator mul = (x, y) -> x * y + y; // Function : lambda Expression
		 Calculator add = (x, y) -> x + y; // Function : lambda Expression
		 Calculator sub = (x, y) -> x - y; // Function : lambda Expression
	       
	        CalculatorImpl imp = new CalculatorImpl();
	        
	     // System.out.println(  imp.calculate(4,6));
	      System.out.println(mul.calculate(4, 6));
	      System.out.println(add.calculate(4, 6));
	      System.out.println(sub.calculate(3, 4));
	}

	/*@Override
	public int calculate(int a, int b) {
		int  mul = a * b;
		return mul;
	}
*/

}
