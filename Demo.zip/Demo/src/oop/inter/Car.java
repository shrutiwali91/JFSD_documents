package oop.inter;

public class Car implements Vehicle {

	public void start() {
		System.out.println("Car started");
	}

	public static void main(String[] args) {
		Car car = new Car();
		car.start();
		car.stop();

	}

}
