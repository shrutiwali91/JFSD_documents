package oop.abst;

public abstract class Shape {

	 public abstract double getArea();
}
