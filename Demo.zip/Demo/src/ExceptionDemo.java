
public class ExceptionDemo {

	// Object -- Throwbale -- Exception -- Specfic () -- JVM, Termnation (If not
	// handled)
	// Exception : Checked (Complitime) , UnCheck(RunTime)

	public int divide(int a, int b) throws MyException {
		int dicvide = 0;
		if (dicvide == 0) {
			throw new MyException();
		}
		
		try {
			dicvide = a - b;
			
		} catch (ArithmeticException e) {
			System.out.println(e.getMessage());
			dicvide = -1;
		}
		System.out.println("This is  outside the try and catch ");
		return dicvide;
	}

	public static void main(String[] args) {
		ExceptionDemo ex = new ExceptionDemo();
		
		try {
			int result = ex.divide(10, 10);
			System.out.println(result);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		/*
		 * int[] a = new int[5]; try { a[1] = 8;
		 * 
		 * try { int x = 10; int result = x / 0; } catch (ArithmeticException e) {
		 * System.out.println(e.getMessage()); }
		 * 
		 * System.out.println("Some othe lines of code"); } catch
		 * (ArrayIndexOutOfBoundsException e) {
		 * 
		 * e.printStackTrace(); } catch (NumberFormatException e) {
		 * System.out.println(e.getMessage()); e.printStackTrace(); } finally { a[2] =
		 * 10; } for (int i = 0; i < a.length; i++) { System.out.println(a[i]); }
		 */

	}

}
