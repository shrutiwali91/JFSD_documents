
public enum MyConst {

	COMPNAY ;
}
