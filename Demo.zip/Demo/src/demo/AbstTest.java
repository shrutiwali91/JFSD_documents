package demo;

public abstract  class AbstTest {
	
	public  int age;
	//Fully (All methods are with abstract keyword., Interface) , Partilly  (one abstract() , another normal method)
	 public abstract int getEmpId();
	 public abstract int getEmpDesginattion();

	 public String getName() {
		 return "Shruti";
	 }
	 
	 public static void main(String[] args) {
			//AbstTest tt = new AbstTest(); 
		}
	

}
