package demo;

public class MyA {

	MyA(){
		System.out.println("I'm the parent class");
	}
	public int age = 25;
	public void myName() {
		System.out.println("Inside MyA class : A");
	}
}
