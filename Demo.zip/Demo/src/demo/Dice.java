package demo;

public class Dice {

	//Variables
	int faces  ;	
	//Costructor
	public Dice() {
		faces = 6;
	}
	public Dice(int faces, int opeartion) {
		faces = faces;
	}	
	public Dice( int face) {
		faces = face;
	}	
	//Getter Method
	public int getFaces () {
		return faces;
	}	
	//Setter Method
	public void setFaces(int numFaces) {
		faces = numFaces;
	}	
	//Clone method
	public Dice clone() {
		Dice d = new Dice(this.faces); // B.GetFaces ();
		//Dice d = new Dice(b.getFaces())  :- b.getFaces() : 4
		//Dice d = new Dice(4);
		return d;
	}
	//Equals Method
	public int equals(Dice d) {
		//c.equals(b)
		//c.getFaces() = b.getFaces();
		return this.faces = d.faces;
	}
	//Main Method
	public static void main(String[] args) {
		
		Dice dd = new Dice(); // Create Object of Class
		System.out.println(dd.getFaces()); //6
		
		Dice b = new Dice(4);
		
		System.out.println(b.getFaces()); //4
		
		Dice c = b.clone();
		System.out.println(c.getFaces()); // 4
		
		
		b.setFaces(3);
		System.out.println(b.getFaces());
		
		System.out.println(c.equals(b));
		
	}
}
