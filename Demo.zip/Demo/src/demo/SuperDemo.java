package demo;

public class SuperDemo {

	public static void main(String[] args) {
		//AbstTest tt = new AbstTest(); 
		One test = new One(); 
		test.age = 30;
		System.out.println(test.age);
		

	}

}
