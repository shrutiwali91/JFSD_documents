package demo;

public class MyC  extends MyB{

	public void myName() {
		System.out.println("Inside MyC class : C");
	}

	public static void main(String[] args) {
		MyA b ;
		b = new MyA();
		b.myName();
		b = new MyB();
		b.myName();
		b = new MyC();
		b.myName();

	}

}

// Types interface
//abstraction
//Polyor

