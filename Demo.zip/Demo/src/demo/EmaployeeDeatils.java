package demo;

//Imports

public interface EmaployeeDeatils extends Emp2 {

	// Normal 
	// Markable
	// Default 
	// Functional Interface
	public int  empId =0;
	
	 // If 
	public String empName ="";
	public String desgination ="";
	public String contactDetails ="";
	
	public  static String companyName ="Goggle"; 
	// public final static String companynme ="goog
	
	
	
	 void getName ();
	 void getEmpDeatils();
	 int returnEmpID();
	// void getContactDetail11s(); // All 10 class needs to be 
	 
	default void getContactDetails() {
		
		 System.out.println(Emp2.empNew);
	 }
		
}
