package demo;

import java.util.Arrays;

public class MyDemo  implements EmaployeeDeatils{

	//Static Bloack
	//Varibale 
	//Method
	//Class level
	  static int x = 10;
	  int y =20;
	  static {
		  System.out.println("This is my static bloack");
	  }
	 
	  static int myMethod() {
		  return 100;
	  }
	  
	  int secondMethod() {
		  int z = 10;
		  return 500;
	  }
	
	static  class myNestedClass {
		 static void m1 () {
			 System.out.println("This is my nested class");
		 }
		 int m2 () {
			 return 1000;
		 }
	  }
	public static void main(String[] args) {
		MyDemo dd = new MyDemo();
		dd.getName();
		dd.getEmpDeatils();
	}

	@Override
	public void getName() {
		System.out.println(" My Name is :: Arun  ");
		
	}

	@Override
	public void getEmpDeatils() {
		System.out.println(" My Employee details are : Name : Shruti, EMp Id : 20");
		
	}

	@Override
	public int returnEmpID() {
		return 0;
	}

}
