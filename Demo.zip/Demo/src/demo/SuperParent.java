package demo;

public class SuperParent {

}
