package demo;

public class One extends AbstTest { // Parent class
	
	public static void main(String[] args) {
		//AbstTest tt = new AbstTest(); 
		One test = new One(); 
		test.age = 30;
		System.out.println(test.age);
		

	}

	@Override
	public int getEmpId() {	
		return 30;
	}

	@Override
	public int getEmpDesginattion() {
		// TODO Auto-generated method stub
		return 0;
	}
	
}
