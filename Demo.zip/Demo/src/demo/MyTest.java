package demo;

import java.io.Serializable;

public  class MyTest  implements EmaployeeDeatils {

	private int empId;
		
	//Getter  method
	public int getEmpId() {
		return empId;
	}

	//Setter
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	
	
	

	public static void main(String[] args) {
		
		MyTest test = new MyTest();
		test.getContactDetails();
		/*test.companyName = "Shruti"; // This will work as you impl the interface
		EmaployeeDeatils.companyName = "Shruti";  // This will give error 
		
		EmaployeeDeatils.empId = 20; // public final int empId = 0		
		test.empId = 20;*/
		
		
	}

	

	@Override
	public void getName() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void getEmpDeatils() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int returnEmpID() {
		// TODO Auto-generated method stub
		return 0;
	}

	

	
}

