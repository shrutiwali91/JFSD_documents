package demo;

public class Poly {

	// Complie time /Static -- Overloading -- within class/ same class
	// RunTime / Dynamic -- Overriding -- Parent and child class

	
	public int sum(int i, int j) {
		return i + j;
	}
	// Overloaded method
	public int sum(int i, int j, int k) {
		return i + j + k;
	}
	
	//Overloaded
	public double sum(int a, double d) {
		return a + d;
	}

	public static void main(String[] args) {
		Poly pp = new Poly();
		
		double dd = pp.sum(10, 20.45);
		System.out.println(pp.sum(10, 20));
		System.out.println(pp.sum(10, 20, 30));
		System.out.println(dd);
		

	}

}
