package demo;

public interface Emp2 {

	public int empNew = 20;
}
