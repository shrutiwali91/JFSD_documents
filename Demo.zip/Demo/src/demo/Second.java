package demo;

public class Second { // Child

	int accountNo;
	String accountName;

	String getAccountName(int accNo) {
		accountNo = accNo;
		if (accountNo == 1) {
			return "SBI Account";
		} else {
			return "NON-SBI Account";
		}

	}
	public static void main(String[] args) {
		//One dd = new Second(); // One dd = new One();
		/*System.out.println(dd.getAccountName(1));
		System.out.println(dd.mutiplication(10));
		System.out.println(dd.myName());*/
		
		//Second dd1 = new One(); // One dd = new One();;--> 
	/*	System.out.println(dd.getAccountName(1));
		System.out.println(dd.mutiplication(10));
		System.out.println(dd.myName());*/
		// From one Class
		
		

	}

}