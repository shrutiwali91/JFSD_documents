package demo;

public  class MyB extends MyA {

	MyB(){
		super();
	}
	
	public int age = 30;
	
	
	public void getParentName() {
		System.out.println(super.age);
		super.myName();
	}

	public static void main(String[] args) {			
		MyB b = new MyB();
		b.getParentName();

	}

}
