package demo;

public class Third  {

	String getCompanyName() {
		return "Google";
	}
	public static void main(String[] args) {
		Third dd = new Third(); // Accepttable : One , second, Third
		//System.out.println(dd.empId);
	//	System.out.println(EmaployeeDeatils.CompnyName);
	}

}
