import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

public class ColelctionDemo {

	//Collection :  - Collections--- List, Set , Map ---- Stack, Vector, Queue
	
	public static void main(String[] args) {
		
		//Set (Map) -- HashSet--  , LinkedHashSet
		
		HashSet<String> mySet = new HashSet<>();
		
		mySet.add("java"); // 1(Hashing mechina -- Genartely) -- Java
		mySet.add("demo"); // 2
		mySet.add("java"); // 1 -- Java
		mySet.add("class"); //23
		
		for(String ss : mySet) {
			System.out.println(ss);
		}
		
		Iterator<String> i = mySet.iterator();
		while (i.hasNext()) {
			System.out.println(i.next());
		}
		
	/*	for(int i=0 ; i < mySet.size(); i++) {
			
			System.out.println(mySet[i]);
		}*/
		/*//List --ArrayList, LinkedList -- Single Data type ,  Duplication
		List<Integer> myList = new ArrayList<>();
		myList.add(10);
		myList.add(3);
		myList.add(300);
		myList.add(17);
		myList.add(1);
		myList.add(5);
		
		System.out.println("Before sorting :: "+myList);
		Collections.sort(myList);
		System.out.println("After Sorting :: "+myList);
		 if(myList.contains(300)) {
			 System.out.println("My Value exist");
		 }
		
		List<Integer> reverse = new ArrayList<>();
		for(int i=myList.size() -1 ; i >= 0; i--) {
			reverse.add(myList.get(i));
		}
		myList = reverse;
		System.out.println(myList);
		
		
		*/
	}
	
}
