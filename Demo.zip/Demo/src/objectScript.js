//As a literal -- key /value pair
const obj = {
  property1: 2, // property name may be an identifier
  2: 10, // or a number
  "property n": "10", // or a string
};

const person = {firstName:"John", lastName:"Doe", age:50, eyeColor:"blue"};

// As a constructor
function Car(make, model, year) {
	  this.make = make;
	  this.model = model;
	  this.year = year;
	}
// creating a obj of car
const kenscar = new Car("Nissan", "300ZX", 1992);
const vpgscar = new Car("Mazda", "Miata", 1990);


function Person(name, age, sex) {
	  this.name = name;
	  this.age = age;
	  this.sex = sex;
	}
const rand = new Person("Rand McKinnon", 33, "M");
const ken = new Person("Ken Jones", 39, "M");

// Using the Object.create() method
// Animal properties and method encapsulation
const Animal = {
  type: "Invertebrates", // Default value of properties
  displayType() {
    // Method which will display type of Animal
    console.log(this.type);
  },
};

// Create new animal type called animal1
const animal1 = Object.create(Animal);
animal1.displayType(); // Logs: Invertebrates

// Create new animal type called fish
const fish = Object.create(Animal);
fish.type = "Fishes";
fish.displayType(); // Logs: Fishes



// Objects and properties
const myCar = {
		  make: "Ford",
		  model: "Mustang",
		  year: 1969,
		};
// Accessing properties
// Dot notation // Not alowed
myCar.make = "Ford";
myCar.model = "Mustang";
myCar.year = 1969;

// Bracket notation // Allowed
myCar["make"] = "Ford";
myCar["model"] = "Mustang";
myCar["year"] = 1969;

// ****************************************************************************

let propertyName = "make";
myCar[propertyName] = "Ford";

// access different properties by changing the contents of the variable
propertyName = "model";
myCar[propertyName] = "Mustang";

// ===========================================================================
const Manager = {
		  name: "Karina",
		  age: 27,
		  job: "Software Engineer",
		};

		const Intern = {
		  name: "Tyrone",
		  age: 21,
		  job: "Software Engineer Intern",
		  myReport : Manager,
		  sayHello : function () {
			  console.log("Hello from Intern");
			}
		  
		};

		function sayHi() {
		  console.log(`Hello, my name is ${this.name}`);
		}
	

		// add sayHi function to both objects
		Manager.sayHi = sayHi;
		Intern.sayHi = sayHi;

		Manager.sayHi(); // Hello, my name is Karina
		Intern.sayHi(); // Hello, my name is Tyrone
		
		console.log(Intern.sayHello())
		console.log("Below nested calling objects")
		console.log(Intern.myReport.name)

// ===========================================================================
		// Defining getters and setters
		
		const myObj = {
				  a: 7,
				  get b() {
				    return this.a + 1;
				  },
				  set c(x) {
				    this.a = x / 2;
				  },
				};

				console.log(myObj.a); // 7
				console.log(myObj.b); // 8, returned from the get b() method
				myObj.c = 50; // Calls the set c(x) method
				console.log(myObj.a); // 25
// ===============================================================================
			// Comparing objects
				
				// Two variables, two distinct objects with the same properties
				const fruit = { name: "apple" };
				const fruitbear = { name: "apple" };

				fruit == fruitbear; // return false
				fruit === fruitbear; // return false
				// +++++++++++++++++++++++++++++++++++++++++++++++++++++
				// Two variables, a single object
				const fruit = { name: "apple" };
				const fruitbear = fruit; // Assign fruit object reference to
											// fruitbear

				// Here fruit and fruitbear are pointing to same object
				fruit == fruitbear; // return true
				fruit === fruitbear; // return true

				fruit.name = "grape";
				console.log(fruitbear); // { name: "grape" }; not { name:
										// "apple" }
				
