/*const myPromise = new Promise((resolve, reject) => {  
    let condition = 10;  
    
    if(condition == 20) {    
        resolve('Promise is resolved successfully.');  
    } else {    
        reject('Promise is rejected');  
    }
});
//then( ) for resolved Promises:
myPromise.then((message) => {  
    console.log(message);
});
//catch( ) for rejected Promises:
myPromise.then((message) => { 
    console.log(message);
}).catch((message) => { 
    console.log(message);
});


//Real exmples
let prom = new Promise((resolve, reject) => {
	  let num= 10 + 10;
	  if (num === 20) {
	    resolve("This resolve should come in the then block");
	  } else {
	    reject("This reject should come in the catch block");
	  }
	});
	prom
	  .then((msg) => console.log("then block -->", msg))
	  .catch((msg) => console.log("catch block -->", msg));
	
	*/

//Callback for Async
/*	function asyncFunction(callback) {
		  console.log("Operation started.");

		  setTimeout(function() {
		    console.log("Operation completed.");
		    callback();
		  }, 2000);
		}

		function callbackFunction() {
		  console.log("Callback function called.");
		  console.log("Operation finished, you can proceed.");
		}

		// Calling asyncFunction and passing callbackFunction as an argument
		asyncFunction(callbackFunction);

		console.log("Program continues...");
		console.log("Program continues outside the callback...");*/
		//output
		/*Operation started.
		Program continues...
		Operation completed.
		Callback function called.
		Operation finished, you can proceed.*/
		
		
//Promise for Async
	/*	function asyncFunction() {
			  console.log("Operation started.");

			  return new Promise(function(resolve, reject) {
			    setTimeout(function() {
			      console.log("Operation completed.");
			      resolve();
			    }, 2000);
			  });
			}

			function callbackFunction() {
			  console.log("Promise resolved successfully.");
			  console.log("Operation finished, you can proceed.");
			}

			// Calling asyncFunction and using the returned Promise with then() and catch() methods
			asyncFunction()
			  .then(callbackFunction)
			  .catch(function(error) {
			    console.log("Promise rejected with error: " + error);
			  });

			console.log("Program continues...");*/
//output
			/*Operation started.
			Program continues...
			Operation completed.
			Promise resolved successfully.
			Operation finished, you can proceed.*/

			
//Async and Await
//The await keyword is used to pause the execution of a 
//function until a Promise is resolved, 
//and it can only be used inside an async function.
			
			async function fetchPostsData() {
				 console.log('before API call:');
				  try {
				    const response = await fetch('https://jsonplaceholder.typicode.com/posts');
				    console.log('response:', response);
				    const data = await response.json();
				    
				    return data;
				  } catch (err) {
				    console.error('Error of fetching posts:', err);
				    throw err;
				  }
				}

const myResult = fetchPostsData()
console.log('myResult:' , myResult);

//Callback Hell vs Async/Await
//Callback 
			function getData(callback) {
				  fetchData(function (err, data) {
				    if (err) {
				      callback(err);
				    } else {
				      processData(data, function (err, result) {
				        if (err) {
				          callback(err);
				        } else {
				          callback(null, result);
				        }
				      });
				    }
				  });
				}
//Async/Await
			async function getData() {
				  try {
				    const data = await fetchData();
				    const result = await processData(data);
				    return result;
				  } catch (err) {
				    throw err;
				  }
				}
				
		
//Fetch exmple 1
			
			async function logMovies() {
				  const response = await fetch("http://example.com/movies.json");
				  const movies = await response.json();
				  console.log(movies);
				}